import TaskList from './TaskList.jsx';
// To try the axios version of the read-only list, swap in:
// import TaskListAxios from './TaskListAxios.jsx';

export default function App() {
  return (
    <div className="app">
      <h1>Task Manager Mini App</h1>
      <TaskList />
      {/* <TaskListAxios /> */}
    </div>
  );
}
