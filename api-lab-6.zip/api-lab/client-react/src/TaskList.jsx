import { useState, useEffect } from 'react';
import { API_URL, API_KEY, readError, describeError } from './api.js';

export default function TaskList() {
  // 3-state pattern: loading, error, data
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  // errors from create / delete / update (list stays visible)
  const [actionError, setActionError] = useState(null);
  const [title, setTitle] = useState('');
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    const controller = new AbortController();

    async function load() {
      try {
        const res = await fetch(`${API_URL}/api/tasks`, { signal: controller.signal });
        if (!res.ok) throw new Error(await readError(res));
        setTasks(await res.json());
      } catch (err) {
        if (err.name !== 'AbortError') setError(describeError(err));
      } finally {
        if (!controller.signal.aborted) setLoading(false);
      }
    }

    load();
    return () => controller.abort();
  }, []);

  async function addTask(e) {
    e.preventDefault();
    if (!title.trim()) return;
    setSaving(true);
    setActionError(null);
    try {
      const res = await fetch(`${API_URL}/api/tasks`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY },
        body: JSON.stringify({ title }),
      });
      if (!res.ok) throw new Error(await readError(res));
      const created = await res.json();
      setTasks((prev) => [...prev, created]);   // UI updates immediately, no reload
      setTitle('');
    } catch (err) {
      setActionError(describeError(err));
    } finally {
      setSaving(false);
    }
  }

  async function deleteTask(id) {
    setActionError(null);
    try {
      const res = await fetch(`${API_URL}/api/tasks/${id}`, {
        method: 'DELETE',
        headers: { 'x-api-key': API_KEY },
      });
      if (!res.ok) throw new Error(await readError(res));
      setTasks((prev) => prev.filter((t) => t.id !== id));
    } catch (err) {
      setActionError(describeError(err));
    }
  }

  async function toggleTask(task) {
    setActionError(null);
    try {
      const res = await fetch(`${API_URL}/api/tasks/${task.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json', 'x-api-key': API_KEY },
        body: JSON.stringify({ completed: !task.completed }),
      });
      if (!res.ok) throw new Error(await readError(res));
      const updated = await res.json();
      setTasks((prev) => prev.map((t) => (t.id === updated.id ? updated : t)));
    } catch (err) {
      setActionError(describeError(err));
    }
  }

  if (loading) return <p className="muted">Loading...</p>;
  if (error) return <div className="error">Could not load tasks: {error}</div>;

  return (
    <>
      <form onSubmit={addTask}>
        <input
          type="text"
          placeholder="New task title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <button type="submit" disabled={saving}>{saving ? 'Adding...' : 'Add'}</button>
      </form>

      {actionError && (
        <div className="error" role="alert">
          {actionError}
          <button onClick={() => setActionError(null)}>Dismiss</button>
        </div>
      )}

      {tasks.length === 0 && <p className="muted">No tasks yet.</p>}
      <ul>
        {tasks.map((task) => (
          <li key={task.id}>
            <input type="checkbox" checked={task.completed} onChange={() => toggleTask(task)} />
            <span className={task.completed ? 'done' : ''}>{task.title}</span>
            <button onClick={() => deleteTask(task.id)}>Delete</button>
          </li>
        ))}
      </ul>

      {/* Q5 test helper: deleting an id that does not exist should show a readable 404 message */}
      <p className="dev">
        Error test: <button onClick={() => deleteTask(9999)}>Delete fake id 9999</button>
      </p>
    </>
  );
}
