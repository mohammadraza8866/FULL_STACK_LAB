import { useState, useEffect } from 'react';
import axios from 'axios';
import { API_URL } from './api.js';

/*
  Same read-only list as TaskList.jsx, rewritten with axios. How it differs from fetch:
  1. JSON parsing: axios parses the body automatically (response.data);
     with fetch you must call `await res.json()` yourself.
  2. Error handling: axios REJECTS the promise for any non-2xx status (404, 401, 500),
     so one catch block handles everything; fetch only rejects on network failure and
     you must check `res.ok` manually.
  3. Error details live in err.response (status, data); err.response is undefined
     when the server could not be reached at all.
  4. Request bodies: axios stringifies objects and sets Content-Type for you;
     with fetch you call JSON.stringify and set the header yourself.
*/
const http = axios.create({ baseURL: API_URL });

function axiosMessage(err) {
  if (err.response) {
    const { status, data } = err.response;
    return `Request failed (${status}): ${data?.error?.message || err.message}`;
  }
  return 'Cannot reach the server. Is it running?';
}

export default function TaskListAxios() {
  const [tasks, setTasks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const controller = new AbortController();
    http
      .get('/api/tasks', { signal: controller.signal })
      .then((res) => setTasks(res.data))            // already parsed JSON
      .catch((err) => {
        if (!axios.isCancel(err)) setError(axiosMessage(err));
      })
      .finally(() => {
        if (!controller.signal.aborted) setLoading(false);
      });
    return () => controller.abort();
  }, []);

  if (loading) return <p className="muted">Loading...</p>;
  if (error) return <div className="error">Could not load tasks: {error}</div>;
  return (
    <ul>
      {tasks.map((t) => (
        <li key={t.id}><span>{t.title}</span></li>
      ))}
    </ul>
  );
}
