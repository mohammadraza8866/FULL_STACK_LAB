// All configuration comes from environment variables (see .env / .env.example).
// NOTE: VITE_* variables are bundled into the browser code, so the API key here is
// not a real secret. Fine for a lab; a real app would use proper user authentication.
export const API_URL = import.meta.env.VITE_API_URL;
export const API_KEY = import.meta.env.VITE_API_KEY;

// Turns a non-OK fetch Response into a readable message (401, 404, others)
export async function readError(res) {
  let detail = '';
  try {
    const data = await res.json();
    detail = data?.error?.message || '';
  } catch {
    /* body was not JSON */
  }
  if (res.status === 401) return `Unauthorized (401): ${detail || 'missing or invalid API key'}`;
  if (res.status === 404) return `Not found (404): ${detail || 'that item does not exist'}`;
  return `Request failed (${res.status}): ${detail || res.statusText}`;
}

// fetch rejects with a TypeError when the server cannot be reached
export function describeError(err) {
  return err instanceof TypeError ? 'Cannot reach the server. Is it running?' : err.message;
}
