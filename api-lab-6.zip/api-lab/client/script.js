const API_URL = 'http://localhost:5000';

const listEl = document.getElementById('task-list');
const statusEl = document.getElementById('status');

async function loadTasks() {
  // loading state
  statusEl.className = 'loading';
  statusEl.textContent = 'Loading...';
  listEl.innerHTML = '';

  try {
    const res = await fetch(`${API_URL}/api/tasks`);
    // fetch only rejects on network failure, so check HTTP status ourselves
    if (!res.ok) throw new Error(`Server responded with status ${res.status}`);
    const tasks = await res.json();

    statusEl.className = '';
    statusEl.textContent = tasks.length ? '' : 'No tasks found.';
    tasks.forEach((task) => {
      const li = document.createElement('li');
      li.textContent = task.title;   // textContent avoids HTML injection
      listEl.appendChild(li);
    });
  } catch (err) {
    // error state: message instead of a broken page
    statusEl.className = 'error';
    statusEl.textContent = `Could not load tasks (${err.message}). Is the server running?`;
  }
}

document.getElementById('reload').addEventListener('click', loadTasks);
loadTasks();
