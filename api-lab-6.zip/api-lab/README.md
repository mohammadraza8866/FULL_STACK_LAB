# Task Manager Mini App (Full Stack Web Development - Lab Sheet 6)

Mohd Raza | CU ID cu24250044 | Roll No 35 | Section B

```
api-lab/
  server/        Express REST API (in-memory tasks, no database)
  client/        Plain JavaScript client (index.html + script.js)
  client-react/  React (Vite) client - full app with create / delete / toggle
  API-Lab.postman_collection.json
```

## Run

```bash
# 1. API  (http://localhost:5000)
cd server
npm install
npm run dev          # nodemon; use "npm start" for plain node

# 2. React client  (http://localhost:5173)   - second terminal
cd client-react
npm install
npm run dev

# 3. Plain JS client - third terminal
cd client
npx serve .          # or open index.html with VS Code Live Server
```

`server/.env` holds PORT, API_KEY and ENABLE_CORS. `client-react/.env` holds VITE_API_URL and
VITE_API_KEY. Both `.env` files are listed in each `.gitignore`; the `.env.example` files show
the required variables.

## API

| Method | URL | Auth (x-api-key) | Notes |
|---|---|---|---|
| GET | /api/tasks | no | list |
| GET | /api/tasks/:id | no | 404 if missing |
| POST | /api/tasks | yes | body `{ "title": "...", "completed": false }`, returns 201 |
| PUT | /api/tasks/:id | yes | partial update of title / completed |
| DELETE | /api/tasks/:id | yes | 404 if missing |

Every error uses one shape: `{ "success": false, "error": { "status": 404, "message": "..." } }`.

## Lab checklist (things you must do and record yourself)

**Q2 - CORS test**
1. In `server/.env` set `ENABLE_CORS=false`, restart the server.
2. Open the plain client (or React app) and look at the browser console. You should see an error
   like: *Access to fetch at 'http://localhost:5000/api/tasks' from origin '...' has been blocked by
   CORS policy: No 'Access-Control-Allow-Origin' header is present on the requested resource.*
   Copy the exact text from YOUR console into your report.
3. Set `ENABLE_CORS=true`, restart, reload the page and confirm the list loads.

**Q2 - Postman**
Import `API-Lab.postman_collection.json`. Run GET all (200), POST without the key (401), then POST
with the key (201) and take a screenshot of the body + response. Collection variables
`baseUrl` and `apiKey` can be edited in the collection settings.

**Q3 - failure path (plain client)**
Open `client/index.html` in the browser, stop the server, click Reload: the red error message
should appear and the page should not break.

**Q5 - graceful errors**
In the React app click "Delete fake id 9999": a readable "Not found (404)" message appears.
To see a 401, temporarily change `VITE_API_KEY` in `client-react/.env`, restart Vite, and add a task.

**Q4 - axios:** `src/TaskListAxios.jsx` is the axios rewrite with the fetch-vs-axios
differences in a comment. Swap it in inside `App.jsx` to try it.
