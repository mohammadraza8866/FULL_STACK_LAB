require('dotenv').config();
const express = require('express');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 5000;

// ---------------------------------------------------------------- data
let tasks = [
  { id: 1, title: 'Set up the Express server', completed: true },
  { id: 2, title: 'Build the CRUD routes', completed: true },
  { id: 3, title: 'Add logger and auth middleware', completed: false },
  { id: 4, title: 'Consume the API with plain JavaScript', completed: false },
  { id: 5, title: 'Build the React client', completed: false },
];
let nextId = tasks.length + 1;

// ---------------------------------------------------------------- helpers
class HttpError extends Error {
  constructor(status, message) {
    super(message);
    this.status = status;
  }
}

function findTask(idParam) {
  const task = tasks.find((t) => t.id === Number(idParam));
  if (!task) throw new HttpError(404, `Task with id ${idParam} not found`);
  return task;
}

function validateTask(body, { titleRequired }) {
  const { title, completed } = body || {};
  if (titleRequired && (typeof title !== 'string' || title.trim() === '')) {
    throw new HttpError(400, 'title is required and must be a non-empty string');
  }
  if (title !== undefined && (typeof title !== 'string' || title.trim() === '')) {
    throw new HttpError(400, 'title must be a non-empty string');
  }
  if (completed !== undefined && typeof completed !== 'boolean') {
    throw new HttpError(400, 'completed must be true or false');
  }
}

// ---------------------------------------------------------------- middleware
// Custom logger: method, URL, timestamp (applied globally)
function logger(req, res, next) {
  console.log(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl}`);
  next();
}

// Auth check: requires x-api-key header (value stored in .env)
function requireApiKey(req, res, next) {
  const expected = process.env.API_KEY;
  if (!expected) return next(new HttpError(500, 'Server misconfigured: API_KEY is not set'));
  if (req.get('x-api-key') !== expected) {
    return next(new HttpError(401, 'Unauthorized: missing or invalid x-api-key header'));
  }
  next();
}

// CORS can be switched off from .env to reproduce the browser error (lab Q2)
if (process.env.ENABLE_CORS !== 'false') {
  app.use(cors());
} else {
  console.warn('CORS is DISABLED (ENABLE_CORS=false)');
}
app.use(express.json());
app.use(logger);

// ---------------------------------------------------------------- routes
app.get('/api/tasks', (req, res) => {
  res.json(tasks);
});

app.get('/api/tasks/:id', (req, res) => {
  res.json(findTask(req.params.id));
});

app.post('/api/tasks', requireApiKey, (req, res) => {
  validateTask(req.body, { titleRequired: true });
  const task = {
    id: nextId++,
    title: req.body.title.trim(),
    completed: req.body.completed === true,
  };
  tasks.push(task);
  res.status(201).json(task);
});

app.put('/api/tasks/:id', requireApiKey, (req, res) => {
  const task = findTask(req.params.id);
  validateTask(req.body, { titleRequired: false });
  if (req.body.title !== undefined) task.title = req.body.title.trim();
  if (req.body.completed !== undefined) task.completed = req.body.completed;
  res.json(task);
});

app.delete('/api/tasks/:id', requireApiKey, (req, res) => {
  const task = findTask(req.params.id);
  tasks = tasks.filter((t) => t.id !== task.id);
  res.json({ message: `Task ${task.id} deleted`, task });
});

// Test route to demonstrate the centralized error handler (any thrown error)
app.get('/api/crash', () => {
  throw new Error('Deliberate test error');
});

// ---------------------------------------------------------------- 404 + error handling
// 404 handler: must come AFTER all routes
app.use((req, res, next) => {
  next(new HttpError(404, `Route ${req.method} ${req.originalUrl} not found`));
});

// Centralized error handler: 4 parameters. Same JSON shape for every error.
// eslint-disable-next-line no-unused-vars
app.use((err, req, res, next) => {
  let status = err.status || err.statusCode || 500;
  let message = err.message;
  if (err.type === 'entity.parse.failed') {
    status = 400;
    message = 'Invalid JSON in request body';
  }
  if (status >= 500) {
    console.error(err);
    message = 'Internal Server Error';
  }
  res.status(status).json({ success: false, error: { status, message } });
});

app.listen(PORT, () => console.log(`API running on http://localhost:${PORT}`));
