// id-gen.js - generates 5 unique IDs using the nanoid package
// Setup: npm init -y  &&  npm install nanoid@3
const { nanoid } = require('nanoid');

console.log('5 unique IDs generated with nanoid:');
for (let i = 1; i <= 5; i++) {
  console.log(`${i}. ${nanoid()}`);
}
