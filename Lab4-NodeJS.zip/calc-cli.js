// calc-cli.js - simple calculator using command-line arguments
// Usage: node calc-cli.js 10 5 +

const args = process.argv.slice(2);

if (args.length !== 3) {
  console.log('Usage: node calc-cli.js <num1> <operator> <num2>');
  console.log('Example: node calc-cli.js 10 5 +');
  process.exit(1);
}

const num1 = parseFloat(args[0]);
const num2 = parseFloat(args[1]);
const operator = args[2];

let result;

switch (operator) {
  case '+':
    result = num1 + num2;
    break;
  case '-':
    result = num1 - num2;
    break;
  case '*':
    result = num1 * num2;
    break;
  case '/':
    if (num2 === 0) {
      console.log('Error: Division by zero is not allowed.');
      process.exit(1);
    }
    result = num1 / num2;
    break;
  default:
    console.log(`Error: Unsupported operator "${operator}". Use +, -, *, or /.`);
    process.exit(1);
}

console.log(`Result: ${num1} ${operator} ${num2} = ${result}`);
