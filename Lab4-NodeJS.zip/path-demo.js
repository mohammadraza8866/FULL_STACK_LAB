// path-demo.js - demonstrates the path module
const path = require('path');

const filePath = '/home/user/data/report.pdf';

console.log('Full path:', filePath);
console.log('Directory name:', path.dirname(filePath));
console.log('Base name:', path.basename(filePath));
console.log('Extension:', path.extname(filePath));

// Resolve an absolute path from a relative one
const relativePath = './data/report.pdf';
const absolutePath = path.resolve(relativePath);
console.log('\nRelative path:', relativePath);
console.log('Resolved absolute path:', absolutePath);
