// order-events.js - custom EventEmitter for an 'orderPlaced' event
const EventEmitter = require('events').EventEmitter;

class OrderEmitter extends EventEmitter {}
const orderEmitter = new OrderEmitter();

// Listener that logs a formatted receipt when an order is placed
orderEmitter.on('orderPlaced', (order) => {
  console.log('--- Receipt ---');
  console.log(`Order ID : ${order.id}`);
  console.log(`Item     : ${order.item}`);
  console.log(`Amount   : $${order.amount.toFixed(2)}`);
  console.log('---------------\n');
});

// Emit the event 3 times with different orders
orderEmitter.emit('orderPlaced', { id: 101, item: 'Laptop', amount: 899.99 });
orderEmitter.emit('orderPlaced', { id: 102, item: 'Wireless Mouse', amount: 25.5 });
orderEmitter.emit('orderPlaced', { id: 103, item: 'Mechanical Keyboard', amount: 79.0 });
