// even-odd.js - exports a function that checks if a number is even or odd
function checkEvenOdd(num) {
  return num % 2 === 0 ? 'even' : 'odd';
}

module.exports = checkEvenOdd;
