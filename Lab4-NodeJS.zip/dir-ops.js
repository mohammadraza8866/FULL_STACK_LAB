// dir-ops.js - directory operations using fs module
const fs = require('fs');
const path = require('path');

const dirName = 'uploads';
const files = ['file1.txt', 'file2.txt', 'file3.txt'];

// 1. Create the uploads folder
fs.mkdir(dirName, (err) => {
  if (err) throw err;
  console.log(`Folder '${dirName}' created.`);

  // 2. Create 3 empty files inside it
  let created = 0;
  files.forEach((file) => {
    const filePath = path.join(dirName, file);
    fs.writeFile(filePath, '', (err) => {
      if (err) throw err;
      created++;
      console.log(`Created ${filePath}`);

      if (created === files.length) {
        // 3. List all files in the folder
        fs.readdir(dirName, (err, list) => {
          if (err) throw err;
          console.log('\nFiles in uploads:', list);

          // 4. Delete one of the files
          const fileToDelete = path.join(dirName, files[0]);
          fs.unlink(fileToDelete, (err) => {
            if (err) throw err;
            console.log(`\nDeleted ${fileToDelete}`);

            fs.readdir(dirName, (err, remaining) => {
              if (err) throw err;
              console.log('Remaining files:', remaining);
            });
          });
        });
      }
    });
  });
});
