// stream-demo.js - writes 50+ lines to a file, then reads it back using a stream
const fs = require('fs');

const fileName = 'large-file.txt';

// 1. Create a text file with at least 50 lines using a loop
let content = '';
for (let i = 1; i <= 60; i++) {
  content += `This is line number ${i} of the stream demo file.\n`;
}

fs.writeFile(fileName, content, (err) => {
  if (err) throw err;
  console.log(`${fileName} created with 60 lines.\n`);

  // 2. Read it back using fs.createReadStream and log each chunk size
  const readStream = fs.createReadStream(fileName, { encoding: 'utf8' });
  let chunkCount = 0;

  readStream.on('data', (chunk) => {
    chunkCount++;
    console.log(`Chunk ${chunkCount} received - size: ${Buffer.byteLength(chunk)} bytes`);
  });

  readStream.on('end', () => {
    console.log(`\nFinished reading. Total chunks received: ${chunkCount}`);
  });

  readStream.on('error', (err) => {
    console.error('Error reading file:', err);
  });
});
