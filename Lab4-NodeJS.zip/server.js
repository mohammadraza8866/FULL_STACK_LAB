// server.js - HTTP server with manual routing (no framework)
const http = require('http');
const url = require('url');

const students = [
  { id: 1, name: 'Raza', course: 'Full Stack Web Development' },
  { id: 2, name: 'Aisha', course: 'Data Structures' },
  { id: 3, name: 'Karan', course: 'Operating Systems' },
];

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const pathName = parsedUrl.pathname;

  // GET /
  if (pathName === '/' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Welcome to the Node.js server!');

  // GET /students
  } else if (pathName === '/students' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(students));

  // GET /students/:id
  } else if (pathName.startsWith('/students/') && req.method === 'GET') {
    const id = parseInt(pathName.split('/')[2], 10);
    const student = students.find((s) => s.id === id);

    res.writeHead(student ? 200 : 404, { 'Content-Type': 'application/json' });
    res.end(
      student
        ? JSON.stringify(student)
        : JSON.stringify({ error: 'Student not found' })
    );

  // Task 8: GET /search?keyword=... using the url module's query parsing
  } else if (pathName === '/search' && req.method === 'GET') {
    const keyword = parsedUrl.query.keyword || '';
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ message: `You searched for: ${keyword}` }));

  // Any other route -> 404 page
  } else {
    res.writeHead(404, { 'Content-Type': 'text/html' });
    res.end('<h1>404 - Page Not Found</h1>');
  }
});

const PORT = 3000;
server.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}/`);
  console.log('Routes: GET /, GET /students, GET /students/:id, GET /search?keyword=');
});
