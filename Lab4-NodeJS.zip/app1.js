// app1.js - imports sum.js and even-odd.js and calls them with sample values
const sum = require('./sum');
const checkEvenOdd = require('./even-odd');

console.log('Sum of 15 and 27:', sum(15, 27));
console.log('Sum of -4 and 9:', sum(-4, 9));

console.log('10 is', checkEvenOdd(10));
console.log('7 is', checkEvenOdd(7));
