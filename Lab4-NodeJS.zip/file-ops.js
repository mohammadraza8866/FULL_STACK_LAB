// file-ops.js - CRUD operations on a text file using fs module
const fs = require('fs');

const originalFile = 'student.txt';
const renamedFile = 'profile.txt';

// 1. Create the file and write name + roll number
fs.writeFile(originalFile, 'Name: Raza\nRoll No: 21CSU001\n', (err) => {
  if (err) throw err;
  console.log(`${originalFile} created and initial content written.`);

  // 2. Append a course name
  fs.appendFile(originalFile, 'Course: Full Stack Web Development\n', (err) => {
    if (err) throw err;
    console.log('Course name appended.');

    // 3. Read and print the full content
    fs.readFile(originalFile, 'utf8', (err, data) => {
      if (err) throw err;
      console.log('\n--- File Content ---');
      console.log(data);
      console.log('--------------------\n');

      // 4. Rename the file
      fs.rename(originalFile, renamedFile, (err) => {
        if (err) throw err;
        console.log(`${originalFile} renamed to ${renamedFile}`);
      });
    });
  });
});
